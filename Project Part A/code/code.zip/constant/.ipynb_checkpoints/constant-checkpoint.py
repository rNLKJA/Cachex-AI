# define global variables
RED = 'Red'
BLUE = 'Blue'
BLOCK = 'Block'